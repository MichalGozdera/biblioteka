CREATE FUNCTION potega(a INT, b INT)
  RETURNS INT
  begin
declare wynik int default 1;
while b>0 do
set wynik=a*wynik;
set b=b-1;
end while;
return wynik;
end;
