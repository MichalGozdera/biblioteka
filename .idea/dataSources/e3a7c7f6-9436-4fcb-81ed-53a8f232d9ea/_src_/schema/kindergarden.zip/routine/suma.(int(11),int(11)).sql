CREATE PROCEDURE suma(IN a INT, IN b INT)
  begin
declare wynik int default 0;
set wynik = a+b;
select concat (a,'+',b,'=',wynik) as dzialanie;
end;
