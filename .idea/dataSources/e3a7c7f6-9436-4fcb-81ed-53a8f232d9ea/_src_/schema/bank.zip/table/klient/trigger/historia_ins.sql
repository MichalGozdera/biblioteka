CREATE TRIGGER historia_ins
AFTER INSERT ON klient
FOR EACH ROW
  BEGIN
DECLARE i INT DEFAULT (select max(id) from klient);

INSERT INTO historia VALUES (null,1,1,null, null, i, 0, 0, null);
END;
