CREATE TRIGGER historia_upd
AFTER UPDATE ON grupa
FOR EACH ROW
  BEGIN
    INSERT INTO log VALUES (null, "update", USER());
END;
