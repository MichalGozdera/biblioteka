create function calculate_salary_by_dept(v_deptno integer) returns numeric
LANGUAGE plpgsql
AS $$
DECLARE
    cur_deps  CURSOR FOR
    Select sum(e.salary)
    from sda.dept d, sda.emp e
    WHERE d.deptno = e.deptno
          AND d.deptno = v_deptno;
  v_salary NUMERIC;
BEGIN
  OPEN cur_deps;
  FETCH cur_deps INTO v_salary;
  CLOSE cur_deps;

  return v_salary;
END;
$$;
