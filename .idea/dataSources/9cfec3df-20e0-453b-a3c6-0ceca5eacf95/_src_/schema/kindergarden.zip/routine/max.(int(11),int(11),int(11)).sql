CREATE FUNCTION max(a INT, b INT, c INT)
  RETURNS INT
  begin
declare temp int;
if a>b then
set temp=a;
set a=b;
set b=temp;
end if;
if b>c then
set temp=b;
set b=c;
set c=temp;
end if;
return c;
end;
