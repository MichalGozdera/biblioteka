CREATE FUNCTION fibo(n INT)
  RETURNS INT
  begin
declare a,b,i,temp int;
set a=1;
set b=2;
if n=1 then 
return a;
elseif n=2 then
return b;
end if;
set i=3;
while i<=n do
set temp=a+b;
set a=b;
set b=temp;
set i=i+1;
end while;
return b;
end;
