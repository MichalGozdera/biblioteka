CREATE FUNCTION kursor()
  RETURNS TEXT
  BEGIN
DECLARE done BOOL DEFAULT FALSE;
DECLARE _nazwisko CHAR(20);
DECLARE cur1 CURSOR FOR SELECT nazwisko from wychowawca;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
SET @wynik = '';
OPEN cur1;
read_loop: LOOP
FETCH cur1 INTO _nazwisko;
IF done THEN
LEAVE read_loop;
END IF;
SET @wynik = CONCAT(@wynik, UPPER(_nazwisko),' ,');
END LOOP;
CLOSE cur1;
SET @wynik = SUBSTR(@wynik, 1, LENGTH(@wynik)-2);
return @wynik;
END;
