CREATE VIEW widoczek AS
  SELECT
    `przedszkole`.`wychowawca`.`id`       AS `id`,
    `przedszkole`.`wychowawca`.`imie`     AS `imie`,
    `przedszkole`.`wychowawca`.`nazwisko` AS `nazwisko`
  FROM `przedszkole`.`wychowawca`;
