CREATE VIEW dept_emp_latest_date AS
  SELECT
    `employees`.`dept_emp`.`emp_no`         AS `emp_no`,
    max(`employees`.`dept_emp`.`from_date`) AS `from_date`,
    max(`employees`.`dept_emp`.`to_date`)   AS `to_date`
  FROM `employees`.`dept_emp`
  GROUP BY `employees`.`dept_emp`.`emp_no`;
